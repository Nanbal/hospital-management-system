import CryptoJS from 'crypto-js';

// Encryption key - in production, this should be stored securely
const ENCRYPTION_KEY = 'securecare-hms-2024-encryption-key-v1';

// Hash password using SHA-256
export const hashPassword = (password: string): string => {
  return CryptoJS.SHA256(password).toString();
};

// Verify password
export const verifyPassword = (password: string, hashedPassword: string): boolean => {
  return hashPassword(password) === hashedPassword;
};

// Encrypt sensitive data
export const encryptData = (data: string): string => {
  try {
    const encrypted = CryptoJS.AES.encrypt(data, ENCRYPTION_KEY);
    return encrypted.toString();
  } catch (error) {
    console.error('Encryption error:', error);
    throw new Error('Failed to encrypt data');
  }
};

// Decrypt sensitive data
export const decryptData = (encryptedData: string): string => {
  try {
    const decrypted = CryptoJS.AES.decrypt(encryptedData, ENCRYPTION_KEY);
    return decrypted.toString(CryptoJS.enc.Utf8);
  } catch (error) {
    console.error('Decryption error:', error);
    throw new Error('Failed to decrypt data');
  }
};

// Encrypt object
export const encryptObject = <T>(obj: T): string => {
  return encryptData(JSON.stringify(obj));
};

// Decrypt object
export const decryptObject = <T>(encryptedData: string): T => {
  return JSON.parse(decryptData(encryptedData));
};

// Generate secure random ID
export const generateSecureId = (): string => {
  return CryptoJS.lib.WordArray.random(16).toString();
};

// Generate patient ID
export const generatePatientId = (): string => {
  const timestamp = Date.now().toString(36).toUpperCase();
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `PT-${timestamp}-${random}`;
};

// Generate bill number
export const generateBillNumber = (): string => {
  const date = new Date();
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const random = Math.random().toString(36).substring(2, 6).toUpperCase();
  return `BILL-${year}${month}-${random}`;
};

// Mask sensitive data
export const maskEmail = (email: string): string => {
  const [local, domain] = email.split('@');
  const maskedLocal = local.charAt(0) + '*'.repeat(local.length - 2) + local.charAt(local.length - 1);
  return `${maskedLocal}@${domain}`;
};

export const maskPhone = (phone: string): string => {
  return phone.replace(/(\d{3})\d{4}(\d{3})/, '$1****$2');
};

export const maskSSN = (ssn: string): string => {
  return ssn.replace(/\d{3}-\d{2}-(\d{4})/, 'XXX-XX-$1');
};
