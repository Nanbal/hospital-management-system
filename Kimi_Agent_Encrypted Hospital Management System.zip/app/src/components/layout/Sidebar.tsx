import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Calendar,
  FileText,
  CreditCard,
  Building2,
  BedDouble,
  Package,
  BarChart3,
  Settings,
  Shield,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Stethoscope,
  UserCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useAuthStore, useUIStore } from '@/store';
import type { UserRole } from '@/types';

interface NavItem {
  label: string;
  path: string;
  icon: React.ElementType;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  {
    label: 'Dashboard',
    path: '/dashboard',
    icon: LayoutDashboard,
    roles: ['admin', 'doctor', 'nurse', 'receptionist', 'pharmacist'],
  },
  {
    label: 'Patients',
    path: '/patients',
    icon: Users,
    roles: ['admin', 'doctor', 'nurse', 'receptionist'],
  },
  {
    label: 'Appointments',
    path: '/appointments',
    icon: Calendar,
    roles: ['admin', 'doctor', 'nurse', 'receptionist'],
  },
  {
    label: 'Medical Records',
    path: '/medical-records',
    icon: FileText,
    roles: ['admin', 'doctor', 'nurse'],
  },
  {
    label: 'Billing',
    path: '/billing',
    icon: CreditCard,
    roles: ['admin', 'receptionist'],
  },
  {
    label: 'Doctors & Staff',
    path: '/staff',
    icon: Stethoscope,
    roles: ['admin'],
  },
  {
    label: 'Departments',
    path: '/departments',
    icon: Building2,
    roles: ['admin'],
  },
  {
    label: 'Rooms & Beds',
    path: '/rooms',
    icon: BedDouble,
    roles: ['admin', 'nurse', 'receptionist'],
  },
  {
    label: 'Inventory',
    path: '/inventory',
    icon: Package,
    roles: ['admin', 'pharmacist'],
  },
  {
    label: 'Reports',
    path: '/reports',
    icon: BarChart3,
    roles: ['admin'],
  },
  {
    label: 'Settings',
    path: '/settings',
    icon: Settings,
    roles: ['admin'],
  },
];

export default function Sidebar() {
  const location = useLocation();
  const { currentUser, logout } = useAuthStore();
  const { sidebarOpen, toggleSidebar } = useUIStore();

  const handleLogout = () => {
    logout();
    window.location.href = '/login';
  };

  const filteredNavItems = navItems.filter((item) =>
    currentUser ? item.roles.includes(currentUser.role) : false
  );

  const getRoleBadgeColor = (role: UserRole) => {
    switch (role) {
      case 'admin':
        return 'bg-red-100 text-red-800';
      case 'doctor':
        return 'bg-blue-100 text-blue-800';
      case 'nurse':
        return 'bg-green-100 text-green-800';
      case 'receptionist':
        return 'bg-purple-100 text-purple-800';
      case 'pharmacist':
        return 'bg-orange-100 text-orange-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <aside
      className={`fixed left-0 top-0 z-40 h-screen bg-white border-r border-gray-200 transition-all duration-300 ${
        sidebarOpen ? 'w-64' : 'w-20'
      }`}
    >
      {/* Header */}
      <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200">
        <div className={`flex items-center gap-3 ${!sidebarOpen && 'justify-center w-full'}`}>
          <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-blue-600 flex-shrink-0">
            <Shield className="w-5 h-5 text-white" />
          </div>
          {sidebarOpen && (
            <div className="overflow-hidden">
              <h1 className="text-lg font-bold text-gray-900 truncate">SecureCare</h1>
              <p className="text-xs text-gray-500 truncate">HMS</p>
            </div>
          )}
        </div>
        {sidebarOpen && (
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="h-8 w-8"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
        )}
      </div>

      {!sidebarOpen && (
        <div className="flex justify-center py-2 border-b border-gray-200">
          <Button
            variant="ghost"
            size="icon"
            onClick={toggleSidebar}
            className="h-8 w-8"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      )}

      {/* Navigation */}
      <ScrollArea className="flex-1 h-[calc(100vh-16rem)]">
        <nav className="p-3 space-y-1">
          {filteredNavItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  isActive
                    ? 'bg-blue-50 text-blue-700'
                    : 'text-gray-700 hover:bg-gray-100'
                } ${!sidebarOpen && 'justify-center'}`}
                title={!sidebarOpen ? item.label : undefined}
              >
                <Icon className={`w-5 h-5 flex-shrink-0 ${isActive ? 'text-blue-700' : 'text-gray-500'}`} />
                {sidebarOpen && (
                  <span className="text-sm font-medium truncate">{item.label}</span>
                )}
              </NavLink>
            );
          })}
        </nav>
      </ScrollArea>

      {/* User Profile */}
      <div className="absolute bottom-0 left-0 right-0 border-t border-gray-200 bg-white">
        <div className={`p-4 ${!sidebarOpen && 'px-2'}`}>
          {sidebarOpen ? (
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200 flex-shrink-0">
                  <UserCircle className="w-6 h-6 text-gray-600" />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 truncate">
                    {currentUser?.firstName} {currentUser?.lastName}
                  </p>
                  <p className="text-xs text-gray-500 truncate">{currentUser?.email}</p>
                  <span
                    className={`inline-block mt-1 px-2 py-0.5 text-xs font-medium rounded-full capitalize ${
                      currentUser ? getRoleBadgeColor(currentUser.role) : ''
                    }`}
                  >
                    {currentUser?.role}
                  </span>
                </div>
              </div>
              <Button
                variant="outline"
                className="w-full"
                onClick={handleLogout}
              >
                <LogOut className="w-4 h-4 mr-2" />
                Sign Out
              </Button>
            </div>
          ) : (
            <div className="flex flex-col items-center gap-2">
              <div className="flex items-center justify-center w-10 h-10 rounded-full bg-gray-200">
                <UserCircle className="w-6 h-6 text-gray-600" />
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={handleLogout}
                className="h-8 w-8"
                title="Sign Out"
              >
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}
