// User Roles
export type UserRole = 'admin' | 'doctor' | 'nurse' | 'receptionist' | 'pharmacist';

// User Interface
export interface User {
  id: string;
  email: string;
  password: string; // hashed
  role: UserRole;
  firstName: string;
  lastName: string;
  phone: string;
  department?: string;
  specialization?: string;
  licenseNumber?: string;
  createdAt: string;
  lastLogin?: string;
  isActive: boolean;
}

// Patient Interface
export interface Patient {
  id: string;
  patientId: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  gender: 'male' | 'female' | 'other';
  bloodGroup?: string;
  phone: string;
  email?: string;
  address: string;
  emergencyContact: {
    name: string;
    phone: string;
    relationship: string;
  };
  insuranceInfo?: {
    provider: string;
    policyNumber: string;
    groupNumber: string;
  };
  allergies: string[];
  medicalHistory: string[];
  createdAt: string;
  updatedAt: string;
}

// Appointment Interface
export interface Appointment {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  department: string;
  date: string;
  time: string;
  duration: number; // in minutes
  type: 'consultation' | 'follow-up' | 'emergency' | 'surgery' | 'checkup';
  status: 'scheduled' | 'completed' | 'cancelled' | 'no-show';
  notes?: string;
  symptoms?: string;
  createdAt: string;
  updatedAt: string;
}

// Medical Record Interface
export interface MedicalRecord {
  id: string;
  patientId: string;
  patientName: string;
  doctorId: string;
  doctorName: string;
  appointmentId?: string;
  date: string;
  diagnosis: string;
  symptoms: string;
  treatment: string;
  prescriptions: Prescription[];
  labResults?: LabResult[];
  notes: string;
  attachments?: string[];
  isEncrypted: boolean;
  createdAt: string;
  updatedAt: string;
}

// Prescription Interface
export interface Prescription {
  id: string;
  medication: string;
  dosage: string;
  frequency: string;
  duration: string;
  instructions: string;
  prescribedBy: string;
  prescribedDate: string;
}

// Lab Result Interface
export interface LabResult {
  id: string;
  testName: string;
  testType: string;
  result: string;
  normalRange?: string;
  unit?: string;
  status: 'normal' | 'abnormal' | 'critical';
  conductedBy: string;
  conductedDate: string;
  notes?: string;
}

// Billing Interface
export interface Bill {
  id: string;
  billNumber: string;
  patientId: string;
  patientName: string;
  items: BillItem[];
  subtotal: number;
  tax: number;
  discount: number;
  total: number;
  amountPaid: number;
  balance: number;
  status: 'pending' | 'partial' | 'paid' | 'overdue';
  paymentMethod?: 'cash' | 'card' | 'insurance' | 'online';
  insuranceClaim?: {
    provider: string;
    claimNumber: string;
    amount: number;
    status: 'pending' | 'approved' | 'rejected';
  };
  createdAt: string;
  dueDate: string;
  paidAt?: string;
}

export interface BillItem {
  id: string;
  description: string;
  quantity: number;
  unitPrice: number;
  total: number;
  category: 'consultation' | 'procedure' | 'medication' | 'lab' | 'room' | 'other';
}

// Department Interface
export interface Department {
  id: string;
  name: string;
  code: string;
  headDoctorId?: string;
  headDoctorName?: string;
  description: string;
  floor: string;
  phone: string;
  isActive: boolean;
}

// Room Interface
export interface Room {
  id: string;
  roomNumber: string;
  type: 'general' | 'private' | 'icu' | 'operation' | 'emergency';
  department: string;
  capacity: number;
  occupied: number;
  status: 'available' | 'occupied' | 'maintenance' | 'reserved';
  equipment: string[];
  dailyRate: number;
}

// Inventory Item Interface
export interface InventoryItem {
  id: string;
  name: string;
  category: 'medication' | 'equipment' | 'supplies' | 'other';
  sku: string;
  quantity: number;
  unit: string;
  minStock: number;
  maxStock: number;
  reorderPoint: number;
  supplier: string;
  unitCost: number;
  expiryDate?: string;
  location: string;
  lastRestocked?: string;
}

// Audit Log Interface
export interface AuditLog {
  id: string;
  userId: string;
  userName: string;
  userRole: UserRole;
  action: 'create' | 'update' | 'delete' | 'view' | 'login' | 'logout' | 'export';
  resource: string;
  resourceId: string;
  details: string;
  timestamp: string;
  ipAddress?: string;
}

// Dashboard Stats
export interface DashboardStats {
  totalPatients: number;
  totalDoctors: number;
  totalAppointments: number;
  todayAppointments: number;
  pendingBills: number;
  totalRevenue: number;
  monthlyRevenue: number;
  occupancyRate: number;
  criticalPatients: number;
}
