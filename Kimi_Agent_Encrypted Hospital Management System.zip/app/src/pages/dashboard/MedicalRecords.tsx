import { useState } from 'react';
import {
  Search,
  Plus,
  FileText,
  Lock,
  Unlock,
  User,
  Stethoscope,
  Calendar,
  Pill,
  MoreHorizontal,
  Edit,
  Trash2,
  Eye,
  Shield,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useMedicalRecordsStore, usePatientsStore, useUsersStore } from '@/store';
import { encryptData, decryptData } from '@/lib/encryption';
import type { MedicalRecord, Prescription } from '@/types';

export default function MedicalRecords() {
  const { records, addRecord, deleteRecord } = useMedicalRecordsStore();
  const { patients } = usePatientsStore();
  const { users } = useUsersStore();
  const doctors = users.filter((u) => u.role === 'doctor');

  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [selectedRecord, setSelectedRecord] = useState<MedicalRecord | null>(null);
  const [decryptedNotes, setDecryptedNotes] = useState<string>('');
  const [showDecrypted, setShowDecrypted] = useState(false);

  const [formData, setFormData] = useState<Partial<MedicalRecord>>({
    patientId: '',
    doctorId: '',
    date: new Date().toISOString().split('T')[0],
    diagnosis: '',
    symptoms: '',
    treatment: '',
    notes: '',
    prescriptions: [],
    isEncrypted: true,
  });

  const [newPrescription, setNewPrescription] = useState<Partial<Prescription>>({
    medication: '',
    dosage: '',
    frequency: '',
    duration: '',
    instructions: '',
  });

  const filteredRecords = records.filter(
    (record) =>
      record.patientName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.doctorName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      record.diagnosis.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleAddRecord = () => {
    const patient = patients.find((p) => p.id === formData.patientId);
    const doctor = doctors.find((d) => d.id === formData.doctorId);

    if (!patient || !doctor) return;

    const notes = formData.isEncrypted && formData.notes
      ? encryptData(formData.notes)
      : formData.notes || '';

    const newRecord: MedicalRecord = {
      id: crypto.randomUUID(),
      patientId: patient.id,
      patientName: `${patient.firstName} ${patient.lastName}`,
      doctorId: doctor.id,
      doctorName: `Dr. ${doctor.firstName} ${doctor.lastName}`,
      date: formData.date || new Date().toISOString().split('T')[0],
      diagnosis: formData.diagnosis || '',
      symptoms: formData.symptoms || '',
      treatment: formData.treatment || '',
      notes,
      prescriptions: formData.prescriptions || [],
      labResults: formData.labResults || [],
      isEncrypted: formData.isEncrypted || false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    addRecord(newRecord);
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleAddPrescription = () => {
    if (newPrescription.medication && newPrescription.dosage) {
      const prescription: Prescription = {
        id: crypto.randomUUID(),
        medication: newPrescription.medication,
        dosage: newPrescription.dosage,
        frequency: newPrescription.frequency || '',
        duration: newPrescription.duration || '',
        instructions: newPrescription.instructions || '',
        prescribedBy: '',
        prescribedDate: new Date().toISOString().split('T')[0],
      };
      setFormData({
        ...formData,
        prescriptions: [...(formData.prescriptions || []), prescription],
      });
      setNewPrescription({
        medication: '',
        dosage: '',
        frequency: '',
        duration: '',
        instructions: '',
      });
    }
  };

  const handleRemovePrescription = (id: string) => {
    setFormData({
      ...formData,
      prescriptions: formData.prescriptions?.filter((p) => p.id !== id) || [],
    });
  };

  const handleDecryptNotes = (record: MedicalRecord) => {
    if (record.isEncrypted && record.notes) {
      try {
        const decrypted = decryptData(record.notes);
        setDecryptedNotes(decrypted);
        setShowDecrypted(true);
      } catch (error) {
        setDecryptedNotes('Unable to decrypt notes');
        setShowDecrypted(true);
      }
    }
  };

  const resetForm = () => {
    setFormData({
      patientId: '',
      doctorId: '',
      date: new Date().toISOString().split('T')[0],
      diagnosis: '',
      symptoms: '',
      treatment: '',
      notes: '',
      prescriptions: [],
      isEncrypted: true,
    });
    setNewPrescription({
      medication: '',
      dosage: '',
      frequency: '',
      duration: '',
      instructions: '',
    });
  };

  const openViewDialog = (record: MedicalRecord) => {
    setSelectedRecord(record);
    setShowDecrypted(false);
    setDecryptedNotes('');
    setIsViewDialogOpen(true);
  };

  const getStatusBadge = (isEncrypted: boolean) => {
    return isEncrypted ? (
      <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
        <Lock className="w-3 h-3 mr-1" />
        Encrypted
      </Badge>
    ) : (
      <Badge variant="outline" className="bg-gray-50 text-gray-700 border-gray-200">
        <Unlock className="w-3 h-3 mr-1" />
        Unencrypted
      </Badge>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Medical Records</h1>
          <p className="text-gray-500 mt-1">Manage patient medical records with encryption</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Add Record
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Add Medical Record</DialogTitle>
              <DialogDescription>
                Create a new medical record. Sensitive notes will be encrypted.
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Patient *</Label>
                  <select
                    className="w-full h-10 px-3 rounded-md border border-input bg-background"
                    value={formData.patientId}
                    onChange={(e) => setFormData({ ...formData, patientId: e.target.value })}
                  >
                    <option value="">Select Patient</option>
                    {patients.map((p) => (
                      <option key={p.id} value={p.id}>
                        {p.firstName} {p.lastName} ({p.patientId})
                      </option>
                    ))}
                  </select>
                </div>
                <div className="space-y-2">
                  <Label>Doctor *</Label>
                  <select
                    className="w-full h-10 px-3 rounded-md border border-input bg-background"
                    value={formData.doctorId}
                    onChange={(e) => setFormData({ ...formData, doctorId: e.target.value })}
                  >
                    <option value="">Select Doctor</option>
                    {doctors.map((d) => (
                      <option key={d.id} value={d.id}>
                        Dr. {d.firstName} {d.lastName}
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Date *</Label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Diagnosis *</Label>
                <Input
                  placeholder="Enter diagnosis"
                  value={formData.diagnosis}
                  onChange={(e) => setFormData({ ...formData, diagnosis: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Symptoms</Label>
                <Textarea
                  placeholder="Describe symptoms..."
                  value={formData.symptoms}
                  onChange={(e) => setFormData({ ...formData, symptoms: e.target.value })}
                />
              </div>

              <div className="space-y-2">
                <Label>Treatment</Label>
                <Textarea
                  placeholder="Describe treatment plan..."
                  value={formData.treatment}
                  onChange={(e) => setFormData({ ...formData, treatment: e.target.value })}
                />
              </div>

              {/* Prescriptions */}
              <div className="border rounded-lg p-4 space-y-4">
                <h4 className="font-medium flex items-center gap-2">
                  <Pill className="w-4 h-4" />
                  Prescriptions
                </h4>
                <div className="grid grid-cols-2 gap-2">
                  <Input
                    placeholder="Medication"
                    value={newPrescription.medication}
                    onChange={(e) => setNewPrescription({ ...newPrescription, medication: e.target.value })}
                  />
                  <Input
                    placeholder="Dosage (e.g., 10mg)"
                    value={newPrescription.dosage}
                    onChange={(e) => setNewPrescription({ ...newPrescription, dosage: e.target.value })}
                  />
                  <Input
                    placeholder="Frequency (e.g., Twice daily)"
                    value={newPrescription.frequency}
                    onChange={(e) => setNewPrescription({ ...newPrescription, frequency: e.target.value })}
                  />
                  <Input
                    placeholder="Duration (e.g., 7 days)"
                    value={newPrescription.duration}
                    onChange={(e) => setNewPrescription({ ...newPrescription, duration: e.target.value })}
                  />
                  <Input
                    placeholder="Instructions"
                    className="col-span-2"
                    value={newPrescription.instructions}
                    onChange={(e) => setNewPrescription({ ...newPrescription, instructions: e.target.value })}
                  />
                </div>
                <Button type="button" variant="outline" onClick={handleAddPrescription}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add Prescription
                </Button>

                {formData.prescriptions && formData.prescriptions.length > 0 && (
                  <div className="space-y-2">
                    {formData.prescriptions.map((prescription) => (
                      <div key={prescription.id} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                        <div>
                          <p className="font-medium">{prescription.medication}</p>
                          <p className="text-sm text-gray-500">
                            {prescription.dosage} - {prescription.frequency}
                          </p>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemovePrescription(prescription.id)}
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </Button>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label>Private Notes (Encrypted)</Label>
                <Textarea
                  placeholder="These notes will be encrypted and only accessible to authorized personnel..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="encrypt"
                  checked={formData.isEncrypted}
                  onChange={(e) => setFormData({ ...formData, isEncrypted: e.target.checked })}
                  className="rounded border-gray-300"
                />
                <Label htmlFor="encrypt" className="flex items-center gap-2">
                  <Lock className="w-4 h-4" />
                  Encrypt sensitive notes
                </Label>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleAddRecord}>Save Record</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Security Notice */}
      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 flex items-start gap-3">
        <Shield className="w-5 h-5 text-blue-600 mt-0.5" />
        <div>
          <h4 className="font-medium text-blue-900">End-to-End Encryption</h4>
          <p className="text-sm text-blue-700">
            All sensitive medical notes are encrypted using AES-256 encryption. Only authorized medical staff can access decrypted content.
          </p>
        </div>
      </div>

      {/* Records List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Medical Records</CardTitle>
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search records..."
                className="pl-10 w-64"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Date</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Doctor</TableHead>
                  <TableHead>Diagnosis</TableHead>
                  <TableHead>Prescriptions</TableHead>
                  <TableHead>Security</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredRecords.length > 0 ? (
                  filteredRecords
                    .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
                    .map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-gray-400" />
                            {new Date(record.date).toLocaleDateString()}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <User className="w-4 h-4 text-gray-400" />
                            {record.patientName}
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex items-center gap-2">
                            <Stethoscope className="w-4 h-4 text-gray-400" />
                            {record.doctorName}
                          </div>
                        </TableCell>
                        <TableCell className="max-w-xs truncate">{record.diagnosis}</TableCell>
                        <TableCell>
                          {record.prescriptions.length > 0 ? (
                            <Badge variant="outline">
                              <Pill className="w-3 h-3 mr-1" />
                              {record.prescriptions.length} medications
                            </Badge>
                          ) : (
                            <span className="text-gray-400">-</span>
                          )}
                        </TableCell>
                        <TableCell>{getStatusBadge(record.isEncrypted)}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openViewDialog(record)}>
                                <Eye className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Edit className="w-4 h-4 mr-2" />
                                Edit
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-red-600"
                                onClick={() => deleteRecord(record.id)}
                              >
                                <Trash2 className="w-4 h-4 mr-2" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-gray-500">
                      <FileText className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No medical records found</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Record Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          {selectedRecord && (
            <>
              <DialogHeader>
                <DialogTitle>Medical Record Details</DialogTitle>
              </DialogHeader>
              <Tabs defaultValue="details" className="w-full">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="details">Details</TabsTrigger>
                  <TabsTrigger value="prescriptions">Prescriptions</TabsTrigger>
                  <TabsTrigger value="notes">Private Notes</TabsTrigger>
                </TabsList>

                <TabsContent value="details" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm text-gray-500">Patient</p>
                      <p className="font-medium">{selectedRecord.patientName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Date</p>
                      <p className="font-medium">
                        {new Date(selectedRecord.date).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Doctor</p>
                      <p className="font-medium">{selectedRecord.doctorName}</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-500">Security</p>
                      {getStatusBadge(selectedRecord.isEncrypted)}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <h4 className="font-medium mb-2">Diagnosis</h4>
                      <p>{selectedRecord.diagnosis}</p>
                    </div>

                    {selectedRecord.symptoms && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium mb-2">Symptoms</h4>
                        <p>{selectedRecord.symptoms}</p>
                      </div>
                    )}

                    {selectedRecord.treatment && (
                      <div className="p-4 bg-gray-50 rounded-lg">
                        <h4 className="font-medium mb-2">Treatment</h4>
                        <p>{selectedRecord.treatment}</p>
                      </div>
                    )}
                  </div>
                </TabsContent>

                <TabsContent value="prescriptions">
                  {selectedRecord.prescriptions.length > 0 ? (
                    <div className="space-y-3">
                      {selectedRecord.prescriptions.map((prescription) => (
                        <div key={prescription.id} className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-start gap-3">
                            <Pill className="w-5 h-5 text-blue-500 mt-0.5" />
                            <div>
                              <p className="font-medium">{prescription.medication}</p>
                              <p className="text-sm text-gray-600">
                                {prescription.dosage} • {prescription.frequency}
                              </p>
                              <p className="text-sm text-gray-500">
                                Duration: {prescription.duration}
                              </p>
                              {prescription.instructions && (
                                <p className="text-sm text-gray-600 mt-2">
                                  <strong>Instructions:</strong> {prescription.instructions}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-center text-gray-500 py-8">No prescriptions</p>
                  )}
                </TabsContent>

                <TabsContent value="notes">
                  {selectedRecord.isEncrypted ? (
                    <div className="space-y-4">
                      {!showDecrypted ? (
                        <div className="text-center py-8">
                          <Lock className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                          <p className="text-gray-500 mb-4">
                            These notes are encrypted for security
                          </p>
                          <Button onClick={() => handleDecryptNotes(selectedRecord)}>
                            <Unlock className="w-4 h-4 mr-2" />
                            Decrypt Notes
                          </Button>
                        </div>
                      ) : (
                        <div className="p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between mb-2">
                            <h4 className="font-medium flex items-center gap-2">
                              <Unlock className="w-4 h-4 text-green-500" />
                              Decrypted Notes
                            </h4>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => setShowDecrypted(false)}
                            >
                              Hide
                            </Button>
                          </div>
                          <p className="whitespace-pre-wrap">{decryptedNotes}</p>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="p-4 bg-gray-50 rounded-lg">
                      <p className="whitespace-pre-wrap">{selectedRecord.notes}</p>
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
