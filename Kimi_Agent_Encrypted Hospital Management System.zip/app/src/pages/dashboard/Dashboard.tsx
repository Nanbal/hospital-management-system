import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Users,
  Calendar,
  CreditCard,
  TrendingUp,
  TrendingDown,
  Activity,
  BedDouble,
  AlertCircle,
  Clock,
  CheckCircle,
  MoreHorizontal,
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { useAuthStore, usePatientsStore, useAppointmentsStore, useBillsStore, useRoomsStore, useInventoryStore } from '@/store';
import { initializeMockData } from '@/lib/mockData';
import { useUsersStore } from '@/store';

interface StatCardProps {
  title: string;
  value: string | number;
  description: string;
  icon: React.ElementType;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color: string;
}

function StatCard({ title, value, description, icon: Icon, trend, trendValue, color }: StatCardProps) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-gray-600">{title}</CardTitle>
        <div className={`p-2 rounded-lg ${color}`}>
          <Icon className="w-4 h-4 text-white" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        <div className="flex items-center gap-2 mt-1">
          {trend && (
            <span
              className={`flex items-center text-xs ${
                trend === 'up' ? 'text-green-600' : trend === 'down' ? 'text-red-600' : 'text-gray-600'
              }`}
            >
              {trend === 'up' ? (
                <TrendingUp className="w-3 h-3 mr-1" />
              ) : trend === 'down' ? (
                <TrendingDown className="w-3 h-3 mr-1" />
              ) : null}
              {trendValue}
            </span>
          )}
          <p className="text-xs text-gray-500">{description}</p>
        </div>
      </CardContent>
    </Card>
  );
}

export default function Dashboard() {
  const navigate = useNavigate();
  const { currentUser } = useAuthStore();
  const { patients, addPatient } = usePatientsStore();
  const { appointments, addAppointment } = useAppointmentsStore();
  const { bills, addBill } = useBillsStore();
  const { rooms, addRoom } = useRoomsStore();
  const { items, addItem } = useInventoryStore();
  const { users, addUser } = useUsersStore();

  // Initialize mock data if needed
  useEffect(() => {
    if (users.length === 0) {
      const mockData = initializeMockData();
      mockData.users.forEach((u) => addUser(u));
      mockData.patients.forEach((p) => addPatient(p));
      mockData.appointments.forEach((a) => addAppointment(a));
      mockData.bills.forEach((b) => addBill(b));
      mockData.departments.forEach(() => {});
      mockData.rooms.forEach((r) => addRoom(r));
      mockData.inventory.forEach((i) => addItem(i));
    }
  }, []);

  // Calculate statistics
  const totalPatients = patients.length;
  const todayAppointments = appointments.filter(
    (a) => a.date === new Date().toISOString().split('T')[0]
  ).length;
  const pendingBills = bills.filter((b) => b.status === 'pending' || b.status === 'partial').length;
  const totalRevenue = bills.reduce((sum, b) => sum + b.amountPaid, 0);
  const monthlyRevenue = bills
    .filter((b) => {
      const billDate = new Date(b.createdAt);
      const now = new Date();
      return billDate.getMonth() === now.getMonth() && billDate.getFullYear() === now.getFullYear();
    })
    .reduce((sum, b) => sum + b.total, 0);
  const occupiedRooms = rooms.filter((r) => r.status === 'occupied').length;
  const totalRooms = rooms.length;
  const occupancyRate = totalRooms > 0 ? Math.round((occupiedRooms / totalRooms) * 100) : 0;
  const lowStockItems = items.filter((i) => i.quantity <= i.reorderPoint).length;

  // Today's appointments
  const todaysAppointments = appointments
    .filter((a) => a.date === new Date().toISOString().split('T')[0])
    .slice(0, 5);

  // Recent patients
  const recentPatients = [...patients]
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5);

  // Pending bills
  const pendingBillsList = bills
    .filter((b) => b.status === 'pending' || b.status === 'partial')
    .slice(0, 5);

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">Scheduled</Badge>;
      case 'completed':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Completed</Badge>;
      case 'cancelled':
        return <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">Cancelled</Badge>;
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-50 text-yellow-700 border-yellow-200">Pending</Badge>;
      case 'paid':
        return <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">Paid</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  const getAppointmentTypeIcon = (type: string) => {
    switch (type) {
      case 'consultation':
        return <Activity className="w-4 h-4 text-blue-500" />;
      case 'follow-up':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'emergency':
        return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'checkup':
        return <Clock className="w-4 h-4 text-purple-500" />;
      default:
        return <Activity className="w-4 h-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome, {currentUser?.firstName}!
          </h1>
          <p className="text-gray-500 mt-1">
            Here's what's happening at SecureCare Hospital today
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-sm text-gray-500">
            {new Date().toLocaleDateString('en-US', {
              weekday: 'long',
              year: 'numeric',
              month: 'long',
              day: 'numeric',
            })}
          </span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total Patients"
          value={totalPatients}
          description="Registered patients"
          icon={Users}
          trend="up"
          trendValue="+12%"
          color="bg-blue-500"
        />
        <StatCard
          title="Today's Appointments"
          value={todayAppointments}
          description="Scheduled for today"
          icon={Calendar}
          trend="neutral"
          trendValue=""
          color="bg-green-500"
        />
        <StatCard
          title="Pending Bills"
          value={pendingBills}
          description="Awaiting payment"
          icon={CreditCard}
          trend="down"
          trendValue="-5%"
          color="bg-orange-500"
        />
        <StatCard
          title="Monthly Revenue"
          value={`$${monthlyRevenue.toLocaleString()}`}
          description="This month"
          icon={TrendingUp}
          trend="up"
          trendValue="+8%"
          color="bg-purple-500"
        />
      </div>

      {/* Secondary Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Room Occupancy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">{occupancyRate}%</span>
              <BedDouble className="w-5 h-5 text-gray-400" />
            </div>
            <Progress value={occupancyRate} className="h-2" />
            <p className="text-xs text-gray-500 mt-2">
              {occupiedRooms} of {totalRooms} rooms occupied
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">${totalRevenue.toLocaleString()}</span>
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-xs text-gray-500">
              Lifetime revenue collected
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Low Stock Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between mb-2">
              <span className="text-2xl font-bold">{lowStockItems}</span>
              <AlertCircle className={`w-5 h-5 ${lowStockItems > 0 ? 'text-red-500' : 'text-gray-400'}`} />
            </div>
            <p className="text-xs text-gray-500">
              Items below reorder point
            </p>
            {lowStockItems > 0 && (
              <Button
                variant="link"
                className="p-0 h-auto text-xs text-red-600"
                onClick={() => navigate('/inventory')}
              >
                View inventory →
              </Button>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Today's Appointments */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Today's Appointments</CardTitle>
              <CardDescription>Scheduled appointments for today</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/appointments')}>
              View All
            </Button>
          </CardHeader>
          <CardContent>
            {todaysAppointments.length > 0 ? (
              <div className="space-y-3">
                {todaysAppointments.map((appointment) => (
                  <div
                    key={appointment.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white rounded-lg">
                        {getAppointmentTypeIcon(appointment.type)}
                      </div>
                      <div>
                        <p className="font-medium text-sm">{appointment.patientName}</p>
                        <p className="text-xs text-gray-500">
                          {appointment.time} • {appointment.department}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusBadge(appointment.status)}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Calendar className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                <p>No appointments scheduled for today</p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent Patients */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Recent Patients</CardTitle>
              <CardDescription>Recently registered patients</CardDescription>
            </div>
            <Button variant="outline" size="sm" onClick={() => navigate('/patients')}>
              View All
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {recentPatients.map((patient) => (
                <div
                  key={patient.id}
                  className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                >
                  <div className="flex items-center gap-3">
                    <Avatar className="h-10 w-10">
                      <AvatarFallback className="bg-blue-100 text-blue-700">
                        {patient.firstName[0]}{patient.lastName[0]}
                      </AvatarFallback>
                    </Avatar>
                    <div>
                      <p className="font-medium text-sm">
                        {patient.firstName} {patient.lastName}
                      </p>
                      <p className="text-xs text-gray-500">
                        {patient.patientId} • {patient.phone}
                      </p>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => navigate(`/patients?id=${patient.id}`)}
                  >
                    View
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pending Bills */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Pending Bills</CardTitle>
            <CardDescription>Bills awaiting payment</CardDescription>
          </div>
          <Button variant="outline" size="sm" onClick={() => navigate('/billing')}>
            View All
          </Button>
        </CardHeader>
        <CardContent>
          {pendingBillsList.length > 0 ? (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bill Number</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Due Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingBillsList.map((bill) => (
                  <TableRow key={bill.id}>
                    <TableCell className="font-medium">{bill.billNumber}</TableCell>
                    <TableCell>{bill.patientName}</TableCell>
                    <TableCell>${bill.total.toLocaleString()}</TableCell>
                    <TableCell className="text-red-600">${bill.balance.toLocaleString()}</TableCell>
                    <TableCell>{bill.dueDate}</TableCell>
                    <TableCell>{getStatusBadge(bill.status)}</TableCell>
                    <TableCell>
                      <Button variant="ghost" size="icon">
                        <MoreHorizontal className="w-4 h-4" />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <CheckCircle className="w-12 h-12 mx-auto mb-3 text-green-300" />
              <p>All bills are paid!</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
