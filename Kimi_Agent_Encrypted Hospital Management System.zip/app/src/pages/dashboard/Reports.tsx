import {
  TrendingUp,
  Users,
  Calendar,
  DollarSign,
  Download,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { usePatientsStore, useAppointmentsStore, useBillsStore, useUsersStore } from '@/store';

export default function Reports() {
  const { patients } = usePatientsStore();
  const { appointments } = useAppointmentsStore();
  const { bills } = useBillsStore();
  const { users } = useUsersStore();

  const doctors = users.filter((u) => u.role === 'doctor');

  // Calculate statistics
  const totalRevenue = bills.reduce((sum, b) => sum + b.total, 0);
  const totalCollected = bills.reduce((sum, b) => sum + b.amountPaid, 0);
  const pendingAmount = bills.reduce((sum, b) => sum + b.balance, 0);

  // Appointments by type
  const appointmentsByType = appointments.reduce((acc, apt) => {
    acc[apt.type] = (acc[apt.type] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Appointments by status
  const appointmentsByStatus = appointments.reduce((acc, apt) => {
    acc[apt.status] = (acc[apt.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Revenue by month (last 6 months)
  const last6Months = Array.from({ length: 6 }, (_, i) => {
    const date = new Date();
    date.setMonth(date.getMonth() - i);
    return date.toLocaleString('default', { month: 'short', year: 'numeric' });
  }).reverse();

  const revenueByMonth = last6Months.map((month) => {
    const monthBills = bills.filter((b) => {
      const billDate = new Date(b.createdAt);
      return billDate.toLocaleString('default', { month: 'short', year: 'numeric' }) === month;
    });
    return monthBills.reduce((sum, b) => sum + b.total, 0);
  });

  // Department statistics
  const departmentStats = doctors.reduce((acc, doctor) => {
    const dept = doctor.department || 'Unassigned';
    if (!acc[dept]) {
      acc[dept] = { doctors: 0, appointments: 0 };
    }
    acc[dept].doctors++;
    acc[dept].appointments += appointments.filter((a) => a.doctorId === doctor.id).length;
    return acc;
  }, {} as Record<string, { doctors: number; appointments: number }>);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Reports & Analytics</h1>
          <p className="text-gray-500 mt-1">View hospital performance metrics and statistics</p>
        </div>
        <Button variant="outline">
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Patients</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-blue-500" />
              <span className="text-2xl font-bold">{patients.length}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Appointments</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Calendar className="w-5 h-5 text-green-500" />
              <span className="text-2xl font-bold">{appointments.length}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-purple-500" />
              <span className="text-2xl font-bold">${totalRevenue.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Collection Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <span className="text-2xl font-bold">
                {totalRevenue > 0 ? Math.round((totalCollected / totalRevenue) * 100) : 0}%
              </span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Reports */}
      <Tabs defaultValue="appointments" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="appointments">Appointments</TabsTrigger>
          <TabsTrigger value="revenue">Revenue</TabsTrigger>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="patients">Patients</TabsTrigger>
        </TabsList>

        <TabsContent value="appointments" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Appointments by Type</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(appointmentsByType).map(([type, count]) => (
                    <div key={type} className="flex items-center justify-between">
                      <span className="capitalize">{type.replace('-', ' ')}</span>
                      <div className="flex items-center gap-4">
                        <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-blue-500"
                            style={{
                              width: `${(count / appointments.length) * 100}%`,
                            }}
                          />
                        </div>
                        <span className="font-medium w-8">{count}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Appointments by Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {Object.entries(appointmentsByStatus).map(([status, count]) => {
                    const colors: Record<string, string> = {
                      scheduled: 'bg-blue-500',
                      completed: 'bg-green-500',
                      cancelled: 'bg-red-500',
                      'no-show': 'bg-gray-500',
                    };
                    return (
                      <div key={status} className="flex items-center justify-between">
                        <span className="capitalize">{status.replace('-', ' ')}</span>
                        <div className="flex items-center gap-4">
                          <div className="w-32 h-2 bg-gray-100 rounded-full overflow-hidden">
                            <div
                              className={`h-full ${colors[status] || 'bg-gray-500'}`}
                              style={{
                                width: `${(count / appointments.length) * 100}%`,
                              }}
                            />
                          </div>
                          <span className="font-medium w-8">{count}</span>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="revenue" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Revenue Overview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 mb-2">Total Revenue</p>
                  <p className="text-3xl font-bold text-blue-600">
                    ${totalRevenue.toLocaleString()}
                  </p>
                </div>
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 mb-2">Amount Collected</p>
                  <p className="text-3xl font-bold text-green-600">
                    ${totalCollected.toLocaleString()}
                  </p>
                </div>
                <div className="text-center p-6 bg-gray-50 rounded-lg">
                  <p className="text-gray-500 mb-2">Pending Amount</p>
                  <p className="text-3xl font-bold text-red-600">
                    ${pendingAmount.toLocaleString()}
                  </p>
                </div>
              </div>

              <div className="mt-6">
                <h4 className="font-medium mb-4">Revenue Trend (Last 6 Months)</h4>
                <div className="flex items-end gap-2 h-48">
                  {revenueByMonth.map((revenue, i) => {
                    const maxRevenue = Math.max(...revenueByMonth) || 1;
                    const height = (revenue / maxRevenue) * 100;
                    return (
                      <div key={i} className="flex-1 flex flex-col items-center">
                        <div
                          className="w-full bg-blue-500 rounded-t"
                          style={{ height: `${height}%` }}
                        />
                        <p className="text-xs text-gray-500 mt-2">{last6Months[i]}</p>
                        <p className="text-xs font-medium">${(revenue / 1000).toFixed(0)}k</p>
                      </div>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="departments" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Department Statistics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {Object.entries(departmentStats).map(([dept, stats]) => (
                  <div key={dept} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium">{dept}</p>
                      <p className="text-sm text-gray-500">{stats.doctors} doctors</p>
                    </div>
                    <div className="text-right">
                      <p className="text-2xl font-bold">{stats.appointments}</p>
                      <p className="text-sm text-gray-500">appointments</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="patients" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Patient Demographics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>Total Registered Patients</span>
                    <span className="font-bold text-xl">{patients.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Male Patients</span>
                    <span className="font-medium">
                      {patients.filter((p) => p.gender === 'male').length}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Female Patients</span>
                    <span className="font-medium">
                      {patients.filter((p) => p.gender === 'female').length}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Patients with Allergies</span>
                    <span className="font-medium">
                      {patients.filter((p) => p.allergies.length > 0).length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <span>New Patients (This Month)</span>
                    <span className="font-medium">
                      {
                        patients.filter((p) => {
                          const created = new Date(p.createdAt);
                          const now = new Date();
                          return (
                            created.getMonth() === now.getMonth() &&
                            created.getFullYear() === now.getFullYear()
                          );
                        }).length
                      }
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Total Appointments</span>
                    <span className="font-medium">{appointments.length}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Completed Appointments</span>
                    <span className="font-medium">
                      {appointments.filter((a) => a.status === 'completed').length}
                    </span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Cancelled Appointments</span>
                    <span className="font-medium">
                      {appointments.filter((a) => a.status === 'cancelled').length}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
