import { useState } from 'react';
import {
  Search,
  Plus,
  CreditCard,
  DollarSign,
  CheckCircle,
  AlertCircle,
  MoreHorizontal,
  Printer,
  Send,
  Filter,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { useBillsStore, usePatientsStore } from '@/store';
import { generateBillNumber } from '@/lib/encryption';
import type { Bill, BillItem } from '@/types';

export default function Billing() {
  const { bills, addBill, updateBill } = useBillsStore();
  const { patients } = usePatientsStore();
  const [searchQuery, setSearchQuery] = useState('');
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isPaymentDialogOpen, setIsPaymentDialogOpen] = useState(false);
  const [selectedBill, setSelectedBill] = useState<Bill | null>(null);

  const [formData, setFormData] = useState<Partial<Bill>>({
    patientId: '',
    items: [],
    tax: 0,
    discount: 0,
    paymentMethod: 'cash',
  });

  const [newItem, setNewItem] = useState<Partial<BillItem>>({
    description: '',
    quantity: 1,
    unitPrice: 0,
    category: 'consultation',
  });

  const filteredBills = bills.filter(
    (bill) =>
      bill.billNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      bill.patientName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const calculateTotals = (items: BillItem[], tax: number, discount: number) => {
    const subtotal = items.reduce((sum, item) => sum + item.total, 0);
    const taxAmount = (subtotal * tax) / 100;
    const total = subtotal + taxAmount - discount;
    return { subtotal, taxAmount, total };
  };

  const handleAddItem = () => {
    if (newItem.description && newItem.unitPrice && newItem.quantity) {
      const item: BillItem = {
        id: crypto.randomUUID(),
        description: newItem.description,
        quantity: newItem.quantity,
        unitPrice: newItem.unitPrice,
        total: newItem.quantity * newItem.unitPrice,
        category: newItem.category || 'other',
      };
      setFormData({ ...formData, items: [...(formData.items || []), item] });
      setNewItem({ description: '', quantity: 1, unitPrice: 0, category: 'consultation' });
    }
  };

  const handleRemoveItem = (itemId: string) => {
    setFormData({
      ...formData,
      items: formData.items?.filter((item) => item.id !== itemId) || [],
    });
  };

  const handleCreateBill = () => {
    const patient = patients.find((p) => p.id === formData.patientId);
    if (!patient || !formData.items || formData.items.length === 0) return;

    const { subtotal, taxAmount, total } = calculateTotals(
      formData.items,
      formData.tax || 0,
      formData.discount || 0
    );

    const newBill: Bill = {
      id: crypto.randomUUID(),
      billNumber: generateBillNumber(),
      patientId: patient.id,
      patientName: `${patient.firstName} ${patient.lastName}`,
      items: formData.items,
      subtotal,
      tax: taxAmount,
      discount: formData.discount || 0,
      total,
      amountPaid: 0,
      balance: total,
      status: 'pending',
      paymentMethod: formData.paymentMethod,
      createdAt: new Date().toISOString(),
      dueDate: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    };

    addBill(newBill);
    setIsAddDialogOpen(false);
    resetForm();
  };

  const handleRecordPayment = () => {
    if (selectedBill && formData.amountPaid) {
      const newAmountPaid = selectedBill.amountPaid + (formData.amountPaid || 0);
      const newBalance = selectedBill.total - newAmountPaid;
      const newStatus = newBalance <= 0 ? 'paid' : newAmountPaid > 0 ? 'partial' : 'pending';

      updateBill(selectedBill.id, {
        amountPaid: newAmountPaid,
        balance: Math.max(0, newBalance),
        status: newStatus,
        paidAt: newStatus === 'paid' ? new Date().toISOString() : undefined,
      });
      setIsPaymentDialogOpen(false);
      setSelectedBill(null);
    }
  };

  const resetForm = () => {
    setFormData({
      patientId: '',
      items: [],
      tax: 0,
      discount: 0,
      paymentMethod: 'cash',
    });
    setNewItem({ description: '', quantity: 1, unitPrice: 0, category: 'consultation' });
  };

  const openPaymentDialog = (bill: Bill) => {
    setSelectedBill(bill);
    setFormData({ ...formData, amountPaid: 0 });
    setIsPaymentDialogOpen(true);
  };

  const openViewDialog = (bill: Bill) => {
    setSelectedBill(bill);
    setIsViewDialogOpen(true);
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'paid':
        return <Badge className="bg-green-100 text-green-800">Paid</Badge>;
      case 'partial':
        return <Badge className="bg-yellow-100 text-yellow-800">Partial</Badge>;
      case 'pending':
        return <Badge className="bg-red-100 text-red-800">Pending</Badge>;
      case 'overdue':
        return <Badge className="bg-gray-100 text-gray-800">Overdue</Badge>;
      default:
        return <Badge>{status}</Badge>;
    }
  };

  // Statistics
  const totalRevenue = bills.reduce((sum, b) => sum + b.amountPaid, 0);
  const pendingAmount = bills
    .filter((b) => b.status === 'pending' || b.status === 'partial')
    .reduce((sum, b) => sum + b.balance, 0);
  const paidBillsCount = bills.filter((b) => b.status === 'paid').length;
  const pendingBillsCount = bills.filter((b) => b.status === 'pending' || b.status === 'partial').length;

  const { subtotal: currentSubtotal, taxAmount: currentTax, total: currentTotal } = calculateTotals(
    formData.items || [],
    formData.tax || 0,
    formData.discount || 0
  );

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Billing</h1>
          <p className="text-gray-500 mt-1">Manage patient bills and payments</p>
        </div>
        <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Create Bill
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create New Bill</DialogTitle>
              <DialogDescription>Add bill items and calculate totals.</DialogDescription>
            </DialogHeader>
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>Patient *</Label>
                <select
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  value={formData.patientId}
                  onChange={(e) => setFormData({ ...formData, patientId: e.target.value })}
                >
                  <option value="">Select Patient</option>
                  {patients.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.firstName} {p.lastName} ({p.patientId})
                    </option>
                  ))}
                </select>
              </div>

              {/* Add Items */}
              <div className="border rounded-lg p-4 space-y-4">
                <h4 className="font-medium">Add Bill Items</h4>
                <div className="grid grid-cols-12 gap-2">
                  <div className="col-span-4">
                    <Input
                      placeholder="Description"
                      value={newItem.description}
                      onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                    />
                  </div>
                  <div className="col-span-2">
                    <select
                      className="w-full h-10 px-2 rounded-md border border-input bg-background text-sm"
                      value={newItem.category}
                      onChange={(e) => setNewItem({ ...newItem, category: e.target.value as BillItem['category'] })}
                    >
                      <option value="consultation">Consultation</option>
                      <option value="procedure">Procedure</option>
                      <option value="medication">Medication</option>
                      <option value="lab">Lab</option>
                      <option value="room">Room</option>
                      <option value="other">Other</option>
                    </select>
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      placeholder="Qty"
                      value={newItem.quantity}
                      onChange={(e) => setNewItem({ ...newItem, quantity: parseInt(e.target.value) || 1 })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Input
                      type="number"
                      placeholder="Price"
                      value={newItem.unitPrice}
                      onChange={(e) => setNewItem({ ...newItem, unitPrice: parseFloat(e.target.value) || 0 })}
                    />
                  </div>
                  <div className="col-span-2">
                    <Button onClick={handleAddItem} className="w-full">
                      Add
                    </Button>
                  </div>
                </div>

                {/* Items List */}
                {formData.items && formData.items.length > 0 && (
                  <div className="border rounded-lg mt-4">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Description</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Qty</TableHead>
                          <TableHead>Price</TableHead>
                          <TableHead>Total</TableHead>
                          <TableHead className="w-10"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {formData.items.map((item) => (
                          <TableRow key={item.id}>
                            <TableCell>{item.description}</TableCell>
                            <TableCell className="capitalize">{item.category}</TableCell>
                            <TableCell>{item.quantity}</TableCell>
                            <TableCell>${item.unitPrice}</TableCell>
                            <TableCell>${item.total}</TableCell>
                            <TableCell>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleRemoveItem(item.id)}
                              >
                                <AlertCircle className="w-4 h-4 text-red-500" />
                              </Button>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                )}
              </div>

              {/* Totals */}
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Tax (%)</Label>
                  <Input
                    type="number"
                    value={formData.tax}
                    onChange={(e) => setFormData({ ...formData, tax: parseFloat(e.target.value) || 0 })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Discount ($)</Label>
                  <Input
                    type="number"
                    value={formData.discount}
                    onChange={(e) => setFormData({ ...formData, discount: parseFloat(e.target.value) || 0 })}
                  />
                </div>
              </div>

              <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal:</span>
                  <span>${currentSubtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax:</span>
                  <span>${currentTax.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Discount:</span>
                  <span>-${(formData.discount || 0).toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold text-lg border-t pt-2">
                  <span>Total:</span>
                  <span>${currentTotal.toFixed(2)}</span>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={() => setIsAddDialogOpen(false)}>
                Cancel
              </Button>
              <Button onClick={handleCreateBill} disabled={!formData.patientId || !formData.items?.length}>
                Create Bill
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Revenue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <DollarSign className="w-5 h-5 text-green-500" />
              <span className="text-2xl font-bold">${totalRevenue.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending Amount</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <AlertCircle className="w-5 h-5 text-red-500" />
              <span className="text-2xl font-bold">${pendingAmount.toLocaleString()}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Paid Bills</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CheckCircle className="w-5 h-5 text-green-500" />
              <span className="text-2xl font-bold">{paidBillsCount}</span>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending Bills</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <CreditCard className="w-5 h-5 text-orange-500" />
              <span className="text-2xl font-bold">{pendingBillsCount}</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Bills List */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>All Bills</CardTitle>
            <div className="flex items-center gap-4">
              <div className="relative">
                <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                <Input
                  placeholder="Search bills..."
                  className="pl-10 w-64"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Button variant="outline">
                <Filter className="w-4 h-4 mr-2" />
                Filter
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="border rounded-lg">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Bill Number</TableHead>
                  <TableHead>Patient</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Total</TableHead>
                  <TableHead>Paid</TableHead>
                  <TableHead>Balance</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="w-10"></TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredBills.length > 0 ? (
                  filteredBills
                    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
                    .map((bill) => (
                      <TableRow key={bill.id}>
                        <TableCell className="font-medium">{bill.billNumber}</TableCell>
                        <TableCell>{bill.patientName}</TableCell>
                        <TableCell>
                          {new Date(bill.createdAt).toLocaleDateString()}
                        </TableCell>
                        <TableCell>${bill.total.toLocaleString()}</TableCell>
                        <TableCell>${bill.amountPaid.toLocaleString()}</TableCell>
                        <TableCell className={bill.balance > 0 ? 'text-red-600' : 'text-green-600'}>
                          ${bill.balance.toLocaleString()}
                        </TableCell>
                        <TableCell>{getStatusBadge(bill.status)}</TableCell>
                        <TableCell>
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon">
                                <MoreHorizontal className="w-4 h-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openViewDialog(bill)}>
                                <CreditCard className="w-4 h-4 mr-2" />
                                View Details
                              </DropdownMenuItem>
                              {bill.balance > 0 && (
                                <DropdownMenuItem onClick={() => openPaymentDialog(bill)}>
                                  <DollarSign className="w-4 h-4 mr-2" />
                                  Record Payment
                                </DropdownMenuItem>
                              )}
                              <DropdownMenuItem>
                                <Printer className="w-4 h-4 mr-2" />
                                Print Bill
                              </DropdownMenuItem>
                              <DropdownMenuItem>
                                <Send className="w-4 h-4 mr-2" />
                                Email Bill
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={8} className="text-center py-8 text-gray-500">
                      <CreditCard className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No bills found</p>
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* View Bill Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-2xl">
          {selectedBill && (
            <>
              <DialogHeader>
                <DialogTitle>Bill Details - {selectedBill.billNumber}</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <div>
                    <p className="text-sm text-gray-500">Patient</p>
                    <p className="font-medium">{selectedBill.patientName}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-500">Date</p>
                    <p className="font-medium">
                      {new Date(selectedBill.createdAt).toLocaleDateString()}
                    </p>
                  </div>
                </div>

                <div className="border rounded-lg">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Description</TableHead>
                        <TableHead>Qty</TableHead>
                        <TableHead>Price</TableHead>
                        <TableHead>Total</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {selectedBill.items.map((item) => (
                        <TableRow key={item.id}>
                          <TableCell>{item.description}</TableCell>
                          <TableCell>{item.quantity}</TableCell>
                          <TableCell>${item.unitPrice}</TableCell>
                          <TableCell>${item.total}</TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>

                <div className="bg-gray-50 p-4 rounded-lg space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${selectedBill.subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Tax:</span>
                    <span>${selectedBill.tax.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Discount:</span>
                    <span>-${selectedBill.discount.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between font-bold text-lg border-t pt-2">
                    <span>Total:</span>
                    <span>${selectedBill.total.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-green-600">
                    <span>Amount Paid:</span>
                    <span>${selectedBill.amountPaid.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between text-red-600 font-medium">
                    <span>Balance:</span>
                    <span>${selectedBill.balance.toFixed(2)}</span>
                  </div>
                </div>

                <div className="flex justify-between items-center">
                  <div>
                    <p className="text-sm text-gray-500">Status</p>
                    {getStatusBadge(selectedBill.status)}
                  </div>
                  {selectedBill.paidAt && (
                    <div className="text-right">
                      <p className="text-sm text-gray-500">Paid On</p>
                      <p>{new Date(selectedBill.paidAt).toLocaleDateString()}</p>
                    </div>
                  )}
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* Payment Dialog */}
      <Dialog open={isPaymentDialogOpen} onOpenChange={setIsPaymentDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Record Payment</DialogTitle>
            <DialogDescription>
              Enter the payment amount for bill {selectedBill?.billNumber}
            </DialogDescription>
          </DialogHeader>
          {selectedBill && (
            <div className="space-y-4 py-4">
              <div className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between mb-2">
                  <span>Total Amount:</span>
                  <span className="font-medium">${selectedBill.total.toFixed(2)}</span>
                </div>
                <div className="flex justify-between mb-2">
                  <span>Already Paid:</span>
                  <span className="text-green-600">${selectedBill.amountPaid.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-medium">
                  <span>Remaining Balance:</span>
                  <span className="text-red-600">${selectedBill.balance.toFixed(2)}</span>
                </div>
              </div>
              <div className="space-y-2">
                <Label>Payment Amount *</Label>
                <Input
                  type="number"
                  max={selectedBill.balance}
                  value={formData.amountPaid}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      amountPaid: Math.min(parseFloat(e.target.value) || 0, selectedBill.balance),
                    })
                  }
                />
              </div>
              <div className="space-y-2">
                <Label>Payment Method</Label>
                <select
                  className="w-full h-10 px-3 rounded-md border border-input bg-background"
                  value={formData.paymentMethod}
                  onChange={(e) =>
                    setFormData({ ...formData, paymentMethod: e.target.value as Bill['paymentMethod'] })
                  }
                >
                  <option value="cash">Cash</option>
                  <option value="card">Card</option>
                  <option value="insurance">Insurance</option>
                  <option value="online">Online</option>
                </select>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsPaymentDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleRecordPayment}>Record Payment</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
