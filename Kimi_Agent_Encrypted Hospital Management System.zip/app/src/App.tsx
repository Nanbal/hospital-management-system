import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/sonner';
import Login from '@/pages/auth/Login';
import DashboardLayout from '@/components/layout/DashboardLayout';
import Dashboard from '@/pages/dashboard/Dashboard';
import Patients from '@/pages/dashboard/Patients';
import Appointments from '@/pages/dashboard/Appointments';
import MedicalRecords from '@/pages/dashboard/MedicalRecords';
import Billing from '@/pages/dashboard/Billing';
import Staff from '@/pages/dashboard/Staff';
import Departments from '@/pages/dashboard/Departments';
import Rooms from '@/pages/dashboard/Rooms';
import Inventory from '@/pages/dashboard/Inventory';
import Reports from '@/pages/dashboard/Reports';
import Settings from '@/pages/dashboard/Settings';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Routes */}
        <Route path="/login" element={<Login />} />

        {/* Protected Routes */}
        <Route element={<DashboardLayout />}>
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/patients" element={<Patients />} />
          <Route path="/appointments" element={<Appointments />} />
          <Route path="/medical-records" element={<MedicalRecords />} />
          <Route path="/billing" element={<Billing />} />
          <Route path="/staff" element={<Staff />} />
          <Route path="/departments" element={<Departments />} />
          <Route path="/rooms" element={<Rooms />} />
          <Route path="/inventory" element={<Inventory />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/settings" element={<Settings />} />
        </Route>

        {/* Default Redirect */}
        <Route path="/" element={<Navigate to="/login" replace />} />
        <Route path="*" element={<Navigate to="/login" replace />} />
      </Routes>
      <Toaster position="top-right" />
    </BrowserRouter>
  );
}

export default App;
