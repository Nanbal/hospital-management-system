import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type {
  User,
  Patient,
  Appointment,
  MedicalRecord,
  Bill,
  Department,
  Room,
  InventoryItem,
  AuditLog,
  UserRole,
} from '@/types';

// Auth Store
interface AuthState {
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (user: User) => void;
  logout: () => void;
  updateUser: (user: Partial<User>) => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      currentUser: null,
      isAuthenticated: false,
      login: (user) => set({ currentUser: user, isAuthenticated: true }),
      logout: () => set({ currentUser: null, isAuthenticated: false }),
      updateUser: (userData) =>
        set((state) => ({
          currentUser: state.currentUser ? { ...state.currentUser, ...userData } : null,
        })),
    }),
    {
      name: 'hms-auth-storage',
    }
  )
);

// Patients Store
interface PatientsState {
  patients: Patient[];
  addPatient: (patient: Patient) => void;
  updatePatient: (id: string, patient: Partial<Patient>) => void;
  deletePatient: (id: string) => void;
  getPatientById: (id: string) => Patient | undefined;
  searchPatients: (query: string) => Patient[];
}

export const usePatientsStore = create<PatientsState>()(
  persist(
    (set, get) => ({
      patients: [],
      addPatient: (patient) =>
        set((state) => ({ patients: [...state.patients, patient] })),
      updatePatient: (id, patientData) =>
        set((state) => ({
          patients: state.patients.map((p) =>
            p.id === id ? { ...p, ...patientData, updatedAt: new Date().toISOString() } : p
          ),
        })),
      deletePatient: (id) =>
        set((state) => ({
          patients: state.patients.filter((p) => p.id !== id),
        })),
      getPatientById: (id) => get().patients.find((p) => p.id === id),
      searchPatients: (query) => {
        const lowerQuery = query.toLowerCase();
        return get().patients.filter(
          (p) =>
            p.firstName.toLowerCase().includes(lowerQuery) ||
            p.lastName.toLowerCase().includes(lowerQuery) ||
            p.patientId.toLowerCase().includes(lowerQuery) ||
            p.phone.includes(query)
        );
      },
    }),
    {
      name: 'hms-patients-storage',
    }
  )
);

// Appointments Store
interface AppointmentsState {
  appointments: Appointment[];
  addAppointment: (appointment: Appointment) => void;
  updateAppointment: (id: string, appointment: Partial<Appointment>) => void;
  deleteAppointment: (id: string) => void;
  getAppointmentById: (id: string) => Appointment | undefined;
  getTodayAppointments: () => Appointment[];
  getAppointmentsByDoctor: (doctorId: string) => Appointment[];
  getAppointmentsByPatient: (patientId: string) => Appointment[];
}

export const useAppointmentsStore = create<AppointmentsState>()(
  persist(
    (set, get) => ({
      appointments: [],
      addAppointment: (appointment) =>
        set((state) => ({ appointments: [...state.appointments, appointment] })),
      updateAppointment: (id, appointmentData) =>
        set((state) => ({
          appointments: state.appointments.map((a) =>
            a.id === id ? { ...a, ...appointmentData, updatedAt: new Date().toISOString() } : a
          ),
        })),
      deleteAppointment: (id) =>
        set((state) => ({
          appointments: state.appointments.filter((a) => a.id !== id),
        })),
      getAppointmentById: (id) => get().appointments.find((a) => a.id === id),
      getTodayAppointments: () => {
        const today = new Date().toISOString().split('T')[0];
        return get().appointments.filter((a) => a.date === today);
      },
      getAppointmentsByDoctor: (doctorId) =>
        get().appointments.filter((a) => a.doctorId === doctorId),
      getAppointmentsByPatient: (patientId) =>
        get().appointments.filter((a) => a.patientId === patientId),
    }),
    {
      name: 'hms-appointments-storage',
    }
  )
);

// Medical Records Store
interface MedicalRecordsState {
  records: MedicalRecord[];
  addRecord: (record: MedicalRecord) => void;
  updateRecord: (id: string, record: Partial<MedicalRecord>) => void;
  deleteRecord: (id: string) => void;
  getRecordById: (id: string) => MedicalRecord | undefined;
  getRecordsByPatient: (patientId: string) => MedicalRecord[];
}

export const useMedicalRecordsStore = create<MedicalRecordsState>()(
  persist(
    (set, get) => ({
      records: [],
      addRecord: (record) =>
        set((state) => ({ records: [...state.records, record] })),
      updateRecord: (id, recordData) =>
        set((state) => ({
          records: state.records.map((r) =>
            r.id === id ? { ...r, ...recordData, updatedAt: new Date().toISOString() } : r
          ),
        })),
      deleteRecord: (id) =>
        set((state) => ({
          records: state.records.filter((r) => r.id !== id),
        })),
      getRecordById: (id) => get().records.find((r) => r.id === id),
      getRecordsByPatient: (patientId) =>
        get().records.filter((r) => r.patientId === patientId),
    }),
    {
      name: 'hms-medical-records-storage',
    }
  )
);

// Bills Store
interface BillsState {
  bills: Bill[];
  addBill: (bill: Bill) => void;
  updateBill: (id: string, bill: Partial<Bill>) => void;
  deleteBill: (id: string) => void;
  getBillById: (id: string) => Bill | undefined;
  getBillsByPatient: (patientId: string) => Bill[];
  getPendingBills: () => Bill[];
}

export const useBillsStore = create<BillsState>()(
  persist(
    (set, get) => ({
      bills: [],
      addBill: (bill) =>
        set((state) => ({ bills: [...state.bills, bill] })),
      updateBill: (id, billData) =>
        set((state) => ({
          bills: state.bills.map((b) =>
            b.id === id ? { ...b, ...billData } : b
          ),
        })),
      deleteBill: (id) =>
        set((state) => ({
          bills: state.bills.filter((b) => b.id !== id),
        })),
      getBillById: (id) => get().bills.find((b) => b.id === id),
      getBillsByPatient: (patientId) =>
        get().bills.filter((b) => b.patientId === patientId),
      getPendingBills: () =>
        get().bills.filter((b) => b.status === 'pending' || b.status === 'partial'),
    }),
    {
      name: 'hms-bills-storage',
    }
  )
);

// Users Store (for staff management)
interface UsersState {
  users: User[];
  addUser: (user: User) => void;
  updateUser: (id: string, user: Partial<User>) => void;
  deleteUser: (id: string) => void;
  getUserById: (id: string) => User | undefined;
  getUsersByRole: (role: UserRole) => User[];
  getDoctors: () => User[];
}

export const useUsersStore = create<UsersState>()(
  persist(
    (set, get) => ({
      users: [],
      addUser: (user) =>
        set((state) => ({ users: [...state.users, user] })),
      updateUser: (id, userData) =>
        set((state) => ({
          users: state.users.map((u) =>
            u.id === id ? { ...u, ...userData } : u
          ),
        })),
      deleteUser: (id) =>
        set((state) => ({
          users: state.users.filter((u) => u.id !== id),
        })),
      getUserById: (id) => get().users.find((u) => u.id === id),
      getUsersByRole: (role) =>
        get().users.filter((u) => u.role === role),
      getDoctors: () =>
        get().users.filter((u) => u.role === 'doctor'),
    }),
    {
      name: 'hms-users-storage',
    }
  )
);

// Departments Store
interface DepartmentsState {
  departments: Department[];
  addDepartment: (department: Department) => void;
  updateDepartment: (id: string, department: Partial<Department>) => void;
  deleteDepartment: (id: string) => void;
  getDepartmentById: (id: string) => Department | undefined;
}

export const useDepartmentsStore = create<DepartmentsState>()(
  persist(
    (set, get) => ({
      departments: [],
      addDepartment: (department) =>
        set((state) => ({ departments: [...state.departments, department] })),
      updateDepartment: (id, departmentData) =>
        set((state) => ({
          departments: state.departments.map((d) =>
            d.id === id ? { ...d, ...departmentData } : d
          ),
        })),
      deleteDepartment: (id) =>
        set((state) => ({
          departments: state.departments.filter((d) => d.id !== id),
        })),
      getDepartmentById: (id) => get().departments.find((d) => d.id === id),
    }),
    {
      name: 'hms-departments-storage',
    }
  )
);

// Rooms Store
interface RoomsState {
  rooms: Room[];
  addRoom: (room: Room) => void;
  updateRoom: (id: string, room: Partial<Room>) => void;
  deleteRoom: (id: string) => void;
  getRoomById: (id: string) => Room | undefined;
  getAvailableRooms: () => Room[];
}

export const useRoomsStore = create<RoomsState>()(
  persist(
    (set, get) => ({
      rooms: [],
      addRoom: (room) =>
        set((state) => ({ rooms: [...state.rooms, room] })),
      updateRoom: (id, roomData) =>
        set((state) => ({
          rooms: state.rooms.map((r) =>
            r.id === id ? { ...r, ...roomData } : r
          ),
        })),
      deleteRoom: (id) =>
        set((state) => ({
          rooms: state.rooms.filter((r) => r.id !== id),
        })),
      getRoomById: (id) => get().rooms.find((r) => r.id === id),
      getAvailableRooms: () =>
        get().rooms.filter((r) => r.status === 'available'),
    }),
    {
      name: 'hms-rooms-storage',
    }
  )
);

// Inventory Store
interface InventoryState {
  items: InventoryItem[];
  addItem: (item: InventoryItem) => void;
  updateItem: (id: string, item: Partial<InventoryItem>) => void;
  deleteItem: (id: string) => void;
  getItemById: (id: string) => InventoryItem | undefined;
  getLowStockItems: () => InventoryItem[];
}

export const useInventoryStore = create<InventoryState>()(
  persist(
    (set, get) => ({
      items: [],
      addItem: (item) =>
        set((state) => ({ items: [...state.items, item] })),
      updateItem: (id, itemData) =>
        set((state) => ({
          items: state.items.map((i) =>
            i.id === id ? { ...i, ...itemData } : i
          ),
        })),
      deleteItem: (id) =>
        set((state) => ({
          items: state.items.filter((i) => i.id !== id),
        })),
      getItemById: (id) => get().items.find((i) => i.id === id),
      getLowStockItems: () =>
        get().items.filter((i) => i.quantity <= i.reorderPoint),
    }),
    {
      name: 'hms-inventory-storage',
    }
  )
);

// Audit Logs Store
interface AuditLogsState {
  logs: AuditLog[];
  addLog: (log: AuditLog) => void;
  getLogsByUser: (userId: string) => AuditLog[];
  getLogsByResource: (resource: string) => AuditLog[];
}

export const useAuditLogsStore = create<AuditLogsState>()(
  persist(
    (set, get) => ({
      logs: [],
      addLog: (log) =>
        set((state) => ({ logs: [...state.logs, log] })),
      getLogsByUser: (userId) =>
        get().logs.filter((l) => l.userId === userId),
      getLogsByResource: (resource) =>
        get().logs.filter((l) => l.resource === resource),
    }),
    {
      name: 'hms-audit-logs-storage',
    }
  )
);

// UI Store
interface UIState {
  sidebarOpen: boolean;
  theme: 'light' | 'dark';
  toggleSidebar: () => void;
  setTheme: (theme: 'light' | 'dark') => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      sidebarOpen: true,
      theme: 'light',
      toggleSidebar: () =>
        set((state) => ({ sidebarOpen: !state.sidebarOpen })),
      setTheme: (theme) => set({ theme }),
    }),
    {
      name: 'hms-ui-storage',
    }
  )
);
